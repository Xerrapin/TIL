package quiz;

import java.util.Scanner;

public class day03_Quiz3_print {
	public static void main(String[] args) {
		String name = "임재혁";
		int age = 26;
		float height = 175.0f, weight = 67.0f;
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("키 : " + height);
		System.out.println("몸무게 : " + weight);
		
	}
}