<template>
  <div>
      <h5>Vue 개발자 모임 블로그 입니다.</h5>
      <p>Vue로 만들고 있습니다.</p>
  </div>
</template>

<script>
export default {
    name:'Home'
}
</script>

<style>

</style>